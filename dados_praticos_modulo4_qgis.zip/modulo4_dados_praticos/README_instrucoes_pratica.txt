# Conjunto de Dados Práticos - Módulo 4: Análise Espacial e Tomada de Decisão
Disciplina: Geotecnologias Aplicadas aos Recursos Hídricos e Saneamento (ProfÁgua)

Este pacote contém os arquivos necessários para a realização das atividades práticas de quinta-feira:

## Conteúdo do Pacote:
1. `monitoramento_qualidade_chuva.csv`: 
   - 22 pontos de monitoramento geoespacializados (Longitude/Latitude WGS84, EPSG:4326).
   - Variáveis: Precipitação mensal (mm), DBO (mg/L), Turbidez (NTU), Oxigênio Dissolvido (OD mg/L) e Coliformes Termotolerantes (NMP/100mL).
   - Uso: Prática 1 (Interpolação Espacial via IDW e Krigagem).

2. `pesos_criterios_ahp.csv`:
   - Matriz de Saaty normalizada com os autovetores calculados para seleção de áreas para ETE / Aterro Sanitário.
   - Consistência da matriz calculada:
     * Razão de Consistência (CR): 0.015 (CR < 0.10 -> Matriz Consistente!).
     * Pesos:
       - Distância a Corpos Hídricos: 41.6%
       - Declividade: 16.1%
       - Distância a Núcleos Urbanos: 26.2%
       - Uso e Cobertura do Solo: 9.9%
       - Permeabilidade/Geologia: 6.2%

3. `tabela_reclassificacao_notas.csv`:
   - Tabela de padronização das notas de adequabilidade (0 a 10) para cada classe temática.

## Instrução Rápida de Importação no QGIS:
- Abra o QGIS -> Menu `Camada` -> `Adicionar Camada` -> `Adicionar Camada de Texto Delimitado`.
- Selecione `monitoramento_qualidade_chuva.csv`.
- Formato de arquivo: CSV.
- Definição de geometria: Coordenadas do Ponto -> Campo X = `longitude`, Campo Y = `latitude`.
- SRC da geometria: `EPSG:4326 - WGS 84`.
- Recomenda-se exportar e reprojetar para UTM (ex: SIRGAS 2000 / UTM zone 24S - EPSG:31984) antes de rodar os algoritmos de interpolação e distâncias euclidianas.

## Expressão para a Calculadora Raster (WLC / Combinação Linear Ponderada):
Supondo os rasters reclassificados (0 a 10) e a máscara de restrição booleana (Mascara_Restricao = 1 para permitido, 0 para proibido):

Indice_Aptidao = (
  ("R_Dist_Agua@1" * 0.416) + 
  ("R_Declividade@1" * 0.161) + 
  ("R_Dist_Urbana@1" * 0.262) + 
  ("R_Uso_Solo@1" * 0.099) + 
  ("R_Geologia@1" * 0.062)
) * "Mascara_Restricao@1"
